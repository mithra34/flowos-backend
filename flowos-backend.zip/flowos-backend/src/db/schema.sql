-- ─────────────────────────────────────────────────────────────────
-- FlowOS Database Schema
-- Paste this into Hostinger phpMyAdmin > SQL tab and click Go
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS clients (
  id          VARCHAR(36)  PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  company     VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL,
  phone       VARCHAR(30),
  industry    VARCHAR(100),
  website     VARCHAR(255),
  notes       TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS projects (
  id          VARCHAR(36)  PRIMARY KEY,
  client_id   VARCHAR(36)  NOT NULL,
  name        VARCHAR(150) NOT NULL,
  description TEXT,
  priority    ENUM('high','medium','low') DEFAULT 'medium',
  status      ENUM('active','completed','paused') DEFAULT 'active',
  deadline    DATE,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS team_members (
  id          VARCHAR(36)  PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  role        VARCHAR(100) NOT NULL,
  dept        ENUM('Website','SEO','Content') NOT NULL,
  email       VARCHAR(150),
  ini         VARCHAR(3),
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tasks (
  id           VARCHAR(36)  PRIMARY KEY,
  project_id   VARCHAR(36)  NOT NULL,
  title        VARCHAR(200) NOT NULL,
  description  TEXT,
  dept         ENUM('Website','SEO','Content') NOT NULL,
  priority     ENUM('high','medium','low') DEFAULT 'medium',
  status       ENUM('pending','in_progress','blocked','completed') DEFAULT 'pending',
  assigned_to  VARCHAR(36),
  due_date     DATE,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id)  REFERENCES projects(id)     ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES team_members(id) ON DELETE SET NULL
);
