# FlowOS Backend — Node.js + Express + MySQL

## Project Structure

```
flowos-backend/
├── src/
│   ├── server.js          ← Entry point
│   ├── db.js              ← MySQL connection pool
│   └── routes/
│       ├── clients.js     ← /api/clients
│       ├── projects.js    ← /api/projects
│       ├── tasks.js       ← /api/tasks
│       └── team.js        ← /api/team
├── database.sql           ← Run this first in phpMyAdmin
├── .env.example           ← Copy to .env and fill in values
└── package.json
```

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/clients | List all clients |
| POST | /api/clients | Create client |
| PUT | /api/clients/:id | Update client |
| DELETE | /api/clients/:id | Delete client |
| GET | /api/projects | List all projects (with task counts) |
| GET | /api/projects/:id | Get project + all its tasks |
| POST | /api/projects | Create project |
| PUT | /api/projects/:id | Update project |
| DELETE | /api/projects/:id | Delete project |
| GET | /api/tasks | List tasks (filter: ?project_id=&status=&department=) |
| POST | /api/tasks | Create task |
| PUT | /api/tasks/:id | Full update task |
| PATCH | /api/tasks/:id/status | Update status only |
| PATCH | /api/tasks/:id/assign | Assign/unassign member |
| DELETE | /api/tasks/:id | Delete task |
| GET | /api/team | List all members with active task count |
| GET | /api/team/:id | Member + their tasks |
| POST | /api/team | Add member |
| PUT | /api/team/:id | Update member |
| DELETE | /api/team/:id | Remove member |

---

## Hostinger Deployment — Step by Step

### Step 1 — Create MySQL Database
1. Log into Hostinger hPanel
2. Go to **Databases → MySQL Databases**
3. Create a new database (e.g. `u123456789_flowos`)
4. Create a database user and assign full permissions
5. Note down: DB name, DB user, DB password

### Step 2 — Run the SQL Schema
1. In hPanel go to **phpMyAdmin**
2. Select your database
3. Click the **SQL** tab
4. Paste the contents of `database.sql` and click **Go**
5. You should see the 4 tables created + default team inserted

### Step 3 — Upload Backend Files
1. In hPanel go to **Node.js** (under Advanced)
2. Click **Create Application**
   - Node.js version: 18 or 20
   - Application root: `/flowos-backend`
   - Application URL: your domain or subdomain
   - Application startup file: `src/server.js`
3. Click **Save**

### Step 4 — Upload Files via File Manager
1. Go to **File Manager** in hPanel
2. Navigate to the folder you set as Application Root
3. Upload all project files (or use Git — see below)
4. Create a `.env` file (copy from `.env.example`):

```
DB_HOST=localhost
DB_PORT=3306
DB_USER=u123456789_flowosuser
DB_PASSWORD=your_password_here
DB_NAME=u123456789_flowos
PORT=3000
ALLOWED_ORIGIN=https://yourdomain.com
```

### Step 5 — Install Dependencies
1. In Hostinger Node.js manager, click **Run NPM command**
2. Type: `install` and click Run
3. Wait for installation to complete

### Step 6 — Start the App
1. Click **Restart** in the Node.js manager
2. Check the application log — you should see:
   ```
   ✅ MySQL connected successfully
   🚀 FlowOS API running on port 3000
   ```

### Step 7 — Test Your API
Open your browser or use a tool like Postman:
```
https://yourdomain.com/api/health
→ {"status":"ok","timestamp":"..."}

https://yourdomain.com/api/team
→ [...list of 6 default team members...]
```

---

## Connecting the Frontend

In your frontend app, replace any hardcoded data with API calls:

```javascript
// Example: Load all clients
const response = await fetch('https://yourdomain.com/api/clients');
const clients = await response.json();

// Example: Create a client
const response = await fetch('https://yourdomain.com/api/clients', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name, company, email, phone, industry })
});

// Example: Update task status
await fetch(`https://yourdomain.com/api/tasks/${taskId}/status`, {
  method: 'PATCH',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ status: 'in_progress' })
});
```

---

## Local Development

```bash
# Clone / navigate to folder
cd flowos-backend

# Install packages
npm install

# Copy env file and fill in your local MySQL credentials
cp .env.example .env

# Run MySQL locally and import schema
mysql -u root -p < database.sql

# Start dev server with auto-reload
npm run dev

# Server runs at http://localhost:3000
```
