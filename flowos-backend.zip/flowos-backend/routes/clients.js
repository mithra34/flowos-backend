const router = require('express').Router();
const db     = require('../config/db');

// GET all clients
router.get('/', async (_req, res, next) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM clients ORDER BY created_at DESC'
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// GET single client
router.get('/:id', async (req, res, next) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM clients WHERE id = ?', [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Client not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// POST create client
router.post('/', async (req, res, next) => {
  try {
    const { name, company, email, phone, industry, website_url, notes } = req.body;
    if (!name || !company || !email) {
      return res.status(400).json({ error: 'name, company and email are required' });
    }
    const [result] = await db.query(
      `INSERT INTO clients (name, company, email, phone, industry, website_url, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name, company, email, phone || null, industry || null, website_url || null, notes || null]
    );
    const [rows] = await db.query('SELECT * FROM clients WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

// PUT update client
router.put('/:id', async (req, res, next) => {
  try {
    const { name, company, email, phone, industry, website_url, notes } = req.body;
    await db.query(
      `UPDATE clients SET name=?, company=?, email=?, phone=?, industry=?, website_url=?, notes=?
       WHERE id=?`,
      [name, company, email, phone, industry, website_url, notes, req.params.id]
    );
    const [rows] = await db.query('SELECT * FROM clients WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// DELETE client
router.delete('/:id', async (req, res, next) => {
  try {
    await db.query('DELETE FROM clients WHERE id = ?', [req.params.id]);
    res.json({ message: 'Client deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
