const router = require('express').Router();
const db     = require('../config/db');

// GET all tasks (with joins)
router.get('/', async (req, res, next) => {
  try {
    const { project_id, status, dept, assigned_to } = req.query;
    let sql = `
      SELECT t.*,
        p.name   AS project_name,
        tm.name  AS assignee_name,
        tm.role  AS assignee_role,
        tm.dept  AS assignee_dept,
        tm.ini   AS assignee_ini
      FROM tasks t
      LEFT JOIN projects p     ON t.project_id  = p.id
      LEFT JOIN team_members tm ON t.assigned_to = tm.id
      WHERE 1=1
    `;
    const params = [];
    if (project_id)  { sql += ' AND t.project_id = ?';  params.push(project_id); }
    if (status)       { sql += ' AND t.status = ?';       params.push(status); }
    if (dept)         { sql += ' AND t.dept = ?';         params.push(dept); }
    if (assigned_to)  { sql += ' AND t.assigned_to = ?';  params.push(assigned_to); }
    sql += ' ORDER BY t.created_at DESC';

    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (err) { next(err); }
});

// GET single task
router.get('/:id', async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT t.*, p.name AS project_name,
        tm.name AS assignee_name, tm.role AS assignee_role, tm.dept AS assignee_dept
      FROM tasks t
      LEFT JOIN projects p     ON t.project_id  = p.id
      LEFT JOIN team_members tm ON t.assigned_to = tm.id
      WHERE t.id = ?
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Task not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// POST create task
router.post('/', async (req, res, next) => {
  try {
    const { project_id, title, description, dept, priority, assigned_to, due_date } = req.body;
    if (!project_id || !title) {
      return res.status(400).json({ error: 'project_id and title are required' });
    }
    const [result] = await db.query(
      `INSERT INTO tasks (project_id, title, description, dept, priority, assigned_to, due_date, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')`,
      [project_id, title, description || null, dept || 'Website',
       priority || 'medium', assigned_to || null, due_date || null]
    );
    const [rows] = await db.query(`
      SELECT t.*, tm.name AS assignee_name, tm.role AS assignee_role
      FROM tasks t LEFT JOIN team_members tm ON t.assigned_to = tm.id
      WHERE t.id = ?
    `, [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

// PUT full update task
router.put('/:id', async (req, res, next) => {
  try {
    const { title, description, dept, priority, assigned_to, due_date, status } = req.body;
    await db.query(
      `UPDATE tasks SET title=?, description=?, dept=?, priority=?, assigned_to=?, due_date=?, status=?
       WHERE id=?`,
      [title, description, dept, priority, assigned_to || null, due_date || null, status, req.params.id]
    );
    const [rows] = await db.query('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// PATCH update specific fields (status, assignee, etc.)
router.patch('/:id', async (req, res, next) => {
  try {
    const allowed = ['status','assigned_to','priority','due_date','title','description'];
    const fields  = Object.keys(req.body).filter(k => allowed.includes(k));
    if (!fields.length) return res.status(400).json({ error: 'No valid fields to update' });

    const sets   = fields.map(f => `${f} = ?`).join(', ');
    const values = fields.map(f => req.body[f]);
    values.push(req.params.id);

    await db.query(`UPDATE tasks SET ${sets} WHERE id = ?`, values);
    const [rows] = await db.query('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// DELETE task
router.delete('/:id', async (req, res, next) => {
  try {
    await db.query('DELETE FROM tasks WHERE id = ?', [req.params.id]);
    res.json({ message: 'Task deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
