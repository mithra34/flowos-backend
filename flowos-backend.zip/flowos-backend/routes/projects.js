const router = require('express').Router();
const db     = require('../config/db');

// GET all projects (with client name joined)
router.get('/', async (_req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT p.*, c.name AS client_name, c.company AS client_company
      FROM projects p
      LEFT JOIN clients c ON p.client_id = c.id
      ORDER BY p.created_at DESC
    `);
    res.json(rows);
  } catch (err) { next(err); }
});

// GET single project with tasks
router.get('/:id', async (req, res, next) => {
  try {
    const [proj] = await db.query(`
      SELECT p.*, c.name AS client_name, c.company AS client_company
      FROM projects p LEFT JOIN clients c ON p.client_id = c.id
      WHERE p.id = ?
    `, [req.params.id]);
    if (!proj.length) return res.status(404).json({ error: 'Project not found' });

    const [tasks] = await db.query(`
      SELECT t.*, tm.name AS assignee_name, tm.role AS assignee_role, tm.dept AS assignee_dept
      FROM tasks t
      LEFT JOIN team_members tm ON t.assigned_to = tm.id
      WHERE t.project_id = ?
      ORDER BY t.created_at DESC
    `, [req.params.id]);

    res.json({ ...proj[0], tasks });
  } catch (err) { next(err); }
});

// GET projects by client
router.get('/client/:clientId', async (req, res, next) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM projects WHERE client_id = ? ORDER BY created_at DESC',
      [req.params.clientId]
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// POST create project
router.post('/', async (req, res, next) => {
  try {
    const { client_id, name, priority, deadline, description } = req.body;
    if (!client_id || !name) {
      return res.status(400).json({ error: 'client_id and name are required' });
    }
    const [result] = await db.query(
      `INSERT INTO projects (client_id, name, priority, deadline, description, status)
       VALUES (?, ?, ?, ?, ?, 'active')`,
      [client_id, name, priority || 'medium', deadline || null, description || null]
    );
    const [rows] = await db.query('SELECT * FROM projects WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

// PUT update project
router.put('/:id', async (req, res, next) => {
  try {
    const { name, priority, deadline, description, status } = req.body;
    await db.query(
      'UPDATE projects SET name=?, priority=?, deadline=?, description=?, status=? WHERE id=?',
      [name, priority, deadline, description, status, req.params.id]
    );
    const [rows] = await db.query('SELECT * FROM projects WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// DELETE project
router.delete('/:id', async (req, res, next) => {
  try {
    // Tasks are deleted by ON DELETE CASCADE in schema
    await db.query('DELETE FROM projects WHERE id = ?', [req.params.id]);
    res.json({ message: 'Project deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
